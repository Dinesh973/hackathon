import React from 'react'

function Vid() {
  return (
    <div>
 <iframe src="https://ntpstagingall.blob.core.windows.net/ntp-content-staging/content/assets/do_2134773120371752961108/4.mp4" className='frame-pdf' frameBorder="1"></iframe>
    </div>
  )
}

export default Vid