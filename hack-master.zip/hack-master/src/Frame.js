import React from 'react'
import './Collapse.css'

function Frame() {
  return (
    <div>
        <iframe src="http://www.africau.edu/images/default/sample.pdf" className='frame-pdf' frameBorder="1"></iframe>
    </div>
  )
}

export default Frame